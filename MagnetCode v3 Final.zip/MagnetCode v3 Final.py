from machine import Pin, PWM, I2C
import time, mylib, math
from mylib import mpu6050_get_accel, i2c

#PWM is pulse width modulation

#Pins - OUT1 + OUT2
in_1 = Pin(6,Pin.OUT) 
in_2 = Pin(7,Pin.OUT)
enb_a = PWM(Pin(8))

#OUT3 and OUT4
in_3 = Pin(4, Pin.OUT)
in_4 = Pin(3, Pin.OUT)
enb_b = PWM(Pin(2))

#OUT 1 and OUT 2 for the second motor controller
#Second motor controller has suffix b

in_1b = Pin(10, Pin.OUT)
in_2b = Pin(14, Pin.OUT)
enb_ba = PWM(Pin(12))

#OUT3 and OUT4 for the second motor controller
in_3b = Pin(16, Pin.OUT)
in_4b = Pin(19, Pin.OUT)
enb_bb= PWM(Pin(18))

#Set directions of polarity for each magnet 

def directionInitial():
    #Magnet 1
    in_1.low()
    in_2.high()    
    
    #Magnet 2
    in_3.high()
    in_4.low()
    
    #Magnet 3 
    in_1b.high()
    in_2b.low()   

    #Magnet 4 
    in_3b.low()
    in_4b.high()     

    #Set Frequency of each to base of 1htz
    BASE_FREQ = 1000
    enb_bb.freq(BASE_FREQ)    
    enb_ba.freq(BASE_FREQ)
    enb_a.freq(BASE_FREQ)
    enb_b.freq(BASE_FREQ)
    
def strong(x):   #strong / varies from magnet to magnet 
    HIGH_FREQ = 65535
    x.duty_u16(HIGH_FREQ)
    

def medium():
    #Maintain semi-strong balance
    MID_FREQ = 40000
    enb_a.duty_u16(MID_FREQ)
    enb_b.duty_u16(MID_FREQ)
    enb_ba.duty_u16(MID_FREQ)
    enb_bb.duty_u16(MID_FREQ)
    
def weak():
    #Maintain weak balance (easy to offset)
    LOW_FREQ = 25000 
    enb_a.duty_u16(LOW_FREQ)
    enb_b.duty_u16(LOW_FREQ)
    enb_ba.duty_u16(LOW_FREQ)
    enb_bb.duty_u16(LOW_FREQ)

def off():
    #Stop magnetic output 
    ZERO_FREQ = 0
    enb_a.duty_u16(ZERO_FREQ)
    enb_b.duty_u16(ZERO_FREQ)
    enb_ba.duty_u16(ZERO_FREQ)
    enb_bb.duty_u16(ZERO_FREQ)





#Adjustment - Strength 

def runProcess():
    directionInitial()
    try:
        while True:
            #get raw data from accelerometer
            g_x, g_y, g_z = mpu6050_get_accel(i2c)
            #pause so that accelerometer has time to react
            time.sleep_ms(20)
            #convert that into usable angles - angle_x is forward / back tilt, angle_y is left / right tilt
            angle_x = math.degrees(math.atan2(g_y, g_z))
            angle_y = math.degrees(math.atan2(g_x, g_z))
            #set to weak as base line for stability 
            weak()
            SAFE_ZONE = 5
            SAFE_ZONE_LOW = -5
            MOTION_DETECT = 10
            MOTION_DETECT_OPP = -40
            #when x axis shifts up on front side  
            if angle_x > MOTION_DETECT: 
                strong(enb_ba)  
                strong(enb_bb)
                print("Im strong on enb_ba and enb_bb")
            #when y axis shifts down on back side
            if angle_x < MOTION_DETECT_OPP:	
                strong(enb_a)   
                strong(enb_b)
                print("Im strong on enb_a and enb_b")
            #if mostly stable, keep mostly stable / reset to weak
            if angle_y > SAFE_ZONE_LOW and angle_y < SAFE_ZONE and angle_x < SAFE_ZONE and angle_x > SAFE_ZONE_LOW : 
                weak()
                print("Im weak on everything because I am stable")
            #leans towards left
            if angle_y > MOTION_DETECT:
                strong(enb_a)
                strong(enb_ba)
                print("Im strong on enb_a and enb_ba")
            #leans towards right
            if angle_y < MOTION_DETECT_OPP:
                strong(enb_b)
                strong(enb_bb)
                print("Im strong on enb_b and enb_bb")
    except KeyboardInterrupt:
        off()
        print("process halted")

if __name__=="__main__":
    runProcess()
    
    